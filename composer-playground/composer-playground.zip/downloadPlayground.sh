
git clone https://github.com/mbwhite/local-composer-ui.git
cd local-composer-ui
npm install